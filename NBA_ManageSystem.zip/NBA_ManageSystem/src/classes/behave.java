package classes;

public class behave {
	public String name;
	public String number;
	public String score;
	public String assist;
	public String rebound;
	public String misstake;
	
	public void setname(String name) {
		this.name = name;
	}
		public void setnumber(String number) {
		this.number = number;
	}
	
	public void setscore(String score) {
		this.score = score;
	}
	public void setrebound(String rebound) {
		this.rebound = rebound;
	}
	public void setassist(String assit) {
		this.assist = assit;
	}
	public void setmisstake(String misstake) {
		this.misstake = misstake;
	}

	
	
	public String  getname() {
		return name;
	}	
	public String  getnumber() {
		return number;
	}

	public String  getscore() {
		return score;
	}	
		public String  getassit() {
		return assist;
	}
	public String  getrebound() {
		return rebound;
	}



	
	public String  getmisstake() {
		return misstake;
	}
}
