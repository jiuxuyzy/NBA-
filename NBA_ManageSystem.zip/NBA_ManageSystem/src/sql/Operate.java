package sql;

import java.sql.*;
import java.util.ArrayList;

import classes.behave;
import sql.DBConn;


public class Operate {
	Connection conn=DBConn.getConn();
	PreparedStatement pstmt = null;
	
	public ArrayList<behave> SelectAllBehave() {
		try {
			ArrayList<behave> al = new ArrayList<behave>();
			pstmt = conn.prepareStatement("select * from behave");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				behave bh = new behave();
				bh.setname(rs.getString("name"));
				bh.setnumber(rs.getString("number"));
				bh.setscore(rs.getString("score"));
				bh.setassist(rs.getString("assist"));
				bh.setrebound(rs.getString("rebound"));
				bh.setmisstake(rs.getString("misstake"));
				al.add(bh);
			}
			return al;
		}
		catch(Exception e) {
			System.out.println("��ѯbehaveʱ����");
			return null;
		}
		
	}
	
	public void UpdateData(String name,String score,String assist) {
		try {
			System.out.println("name,score,assist"+name+score+assist);
			pstmt = conn.prepareStatement("update behave set score='"+score+"',assist = '"+assist+"' where name='"+name+"';");
			pstmt.execute();
		}
		catch(Exception e) {
			System.out.println("����ʱ���ִ���");
		}
	}
}